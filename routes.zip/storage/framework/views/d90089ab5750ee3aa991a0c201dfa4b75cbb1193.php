<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta http-equiv="x-ua-compatible" content="ie=edge" />
        <title><?php echo $__env->yieldContent('title'); ?></title>
    
        <!-- MDB icon -->
        <link rel="icon" href="<?php echo e(asset('assets/img/mdb-favicon.ico')); ?>" type="image/x-icon" />
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" />
        <!-- Google Fonts Roboto -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"/>

        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
  
        <!-- Material Design Bootstrap -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/mdb.min.css')); ?>">
  
        <!-- Your custom styles (optional) -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

        <?php echo $__env->yieldPushContent('extra-styles'); ?>
    </head>
  
    <body>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- jQuery -->
        <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <!-- Bootstrap tooltips -->
        <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <!-- Bootstrap core JavaScript -->
        <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="<?php echo e(asset('assets/js/mdb.min.js')); ?>"></script>

        <?php echo $__env->yieldPushContent('extra-scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\todo-application\resources\views/layouts/master.blade.php ENDPATH**/ ?>