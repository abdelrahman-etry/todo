<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(Session::get('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('fail')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(Session::get('fail')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close"></button>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\todo-application\resources\views/layouts/messages.blade.php ENDPATH**/ ?>